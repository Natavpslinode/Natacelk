Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, username, password } = await req.json();

        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        if (action === 'login') {
            // Verify admin credentials
            const { data: admin } = await fetch(`${supabaseUrl}/rest/v1/admin_users?username=eq.${username}&is_active=eq.true`, {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }).then(res => res.json());

            if (!admin || admin.length === 0) {
                throw new Error('Credenciales inválidas');
            }

            // For demo purposes, using simple password comparison
            // In production, use proper password hashing
            const adminUser = admin[0];
            if (adminUser.password_hash !== password) {
                throw new Error('Credenciales inválidas');
            }

            // Update last login
            await fetch(`${supabaseUrl}/rest/v1/admin_users?id=eq.${adminUser.id}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    last_login: new Date().toISOString()
                })
            });

            return new Response(JSON.stringify({
                data: {
                    success: true,
                    admin: {
                        id: adminUser.id,
                        username: adminUser.username,
                        full_name: adminUser.full_name,
                        role: adminUser.role
                    }
                }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });

        } else if (action === 'create-admin') {
            // Create initial admin user
            const insertResponse = await fetch(`${supabaseUrl}/rest/v1/admin_users`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    username: 'admin',
                    password_hash: 'meproc2024',
                    full_name: 'Administrador MEPROC',
                    role: 'admin',
                    email: 'admin@meproc.edu',
                    is_active: true
                })
            });

            if (!insertResponse.ok) {
                const errorText = await insertResponse.text();
                throw new Error(`Failed to create admin: ${errorText}`);
            }

            return new Response(JSON.stringify({
                data: {
                    success: true,
                    message: 'Admin user created successfully'
                }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        }

        throw new Error('Invalid action');

    } catch (error) {
        console.error('Admin auth error:', error);

        const errorResponse = {
            error: {
                code: 'ADMIN_AUTH_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});