Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { userId, studentName } = await req.json();

        if (!userId || !studentName) {
            throw new Error('User ID and student name are required');
        }

        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        // Check if user has completed all 10 modules
        const progressResponse = await fetch(
            `${supabaseUrl}/rest/v1/student_progress?user_id=eq.${userId}&is_completed=eq.true&select=count`, 
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        const progressData = await progressResponse.json();
        const completedModules = progressData[0]?.count || 0;

        if (completedModules < 10) {
            throw new Error(`Student has only completed ${completedModules} of 10 modules`);
        }

        // Generate certificate number
        const certificateNumber = `MEPROC-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
        
        // Get completion date (latest module completion)
        const completionResponse = await fetch(
            `${supabaseUrl}/rest/v1/student_progress?user_id=eq.${userId}&is_completed=eq.true&order=completion_date.desc&limit=1`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        const completionData = await completionResponse.json();
        const completionDate = completionData[0]?.completion_date || new Date().toISOString();

        // Generate certificate HTML with exact Spanish content as specified
        const certificateHTML = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Certificado MEPROC</title>
            <style>
                body { 
                    font-family: 'Georgia', serif; 
                    margin: 0; 
                    padding: 20px;
                    background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
                    color: #1a365d;
                    text-align: center;
                    min-height: 100vh;
                }
                .certificate {
                    background: white;
                    max-width: 900px;
                    margin: 0 auto;
                    padding: 80px 60px;
                    border-radius: 20px;
                    box-shadow: 0 25px 50px rgba(0,0,0,0.15);
                    border: 12px solid #1e40af;
                    position: relative;
                }
                .certificate::before {
                    content: '';
                    position: absolute;
                    top: 25px;
                    left: 25px;
                    right: 25px;
                    bottom: 25px;
                    border: 4px solid #f59e0b;
                    border-radius: 10px;
                }
                .logo {
                    width: 80px;
                    height: 80px;
                    margin: 0 auto 30px;
                    z-index: 10;
                    position: relative;
                }
                .header {
                    color: #1e40af;
                    font-size: 24px;
                    font-weight: bold;
                    margin-bottom: 10px;
                    text-transform: uppercase;
                    letter-spacing: 2px;
                    line-height: 1.3;
                    z-index: 10;
                    position: relative;
                }
                .title {
                    font-size: 48px;
                    color: #f59e0b;
                    margin: 40px 0;
                    font-weight: bold;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
                    text-transform: uppercase;
                    letter-spacing: 3px;
                    z-index: 10;
                    position: relative;
                }
                .main-text {
                    font-size: 24px;
                    color: #1e40af;
                    margin: 30px 0 20px;
                    line-height: 1.4;
                    z-index: 10;
                    position: relative;
                }
                .student-name {
                    font-size: 36px;
                    color: #1e40af;
                    margin: 30px 0;
                    font-style: italic;
                    text-decoration: underline;
                    font-weight: bold;
                    z-index: 10;
                    position: relative;
                }
                .course-name {
                    font-size: 28px;
                    color: #374151;
                    margin: 30px 0;
                    line-height: 1.4;
                    font-weight: bold;
                    text-transform: uppercase;
                    z-index: 10;
                    position: relative;
                }
                .year {
                    font-size: 32px;
                    color: #f59e0b;
                    font-weight: bold;
                    margin: 20px 0;
                    z-index: 10;
                    position: relative;
                }
                .congratulations {
                    font-size: 20px;
                    color: #1e40af;
                    margin: 40px 0;
                    font-style: italic;
                    line-height: 1.3;
                    z-index: 10;
                    position: relative;
                }
                .date {
                    font-size: 18px;
                    color: #6b7280;
                    margin: 40px 0;
                    z-index: 10;
                    position: relative;
                }
                .signatures {
                    display: flex;
                    justify-content: space-between;
                    margin-top: 80px;
                    padding: 0 60px;
                    z-index: 10;
                    position: relative;
                }
                .signature {
                    text-align: center;
                    flex: 1;
                }
                .signature-line {
                    border-top: 3px solid #1e40af;
                    width: 200px;
                    margin: 0 auto 15px;
                }
                .signature-title {
                    font-size: 18px;
                    color: #1e40af;
                    font-weight: bold;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                }
                .decorative-border {
                    position: absolute;
                    width: 60px;
                    height: 60px;
                    border: 3px solid #f59e0b;
                    z-index: 5;
                }
                .top-left {
                    top: 50px;
                    left: 50px;
                    border-right: none;
                    border-bottom: none;
                }
                .top-right {
                    top: 50px;
                    right: 50px;
                    border-left: none;
                    border-bottom: none;
                }
                .bottom-left {
                    bottom: 50px;
                    left: 50px;
                    border-right: none;
                    border-top: none;
                }
                .bottom-right {
                    bottom: 50px;
                    right: 50px;
                    border-left: none;
                    border-top: none;
                }
            </style>
        </head>
        <body>
            <div class="certificate">
                <!-- Decorative corners -->
                <div class="decorative-border top-left"></div>
                <div class="decorative-border top-right"></div>
                <div class="decorative-border bottom-left"></div>
                <div class="decorative-border bottom-right"></div>
                
                <!-- MEPROC Logo -->
                <div class="logo">
                    <svg viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="60" cy="60" r="58" fill="url(#gradient1)" stroke="#1e3a8a" stroke-width="4"/>
                        <rect x="55" y="25" width="10" height="35" rx="2" fill="#f59e0b"/>
                        <rect x="40" y="40" width="40" height="10" rx="2" fill="#f59e0b"/>
                        <rect x="30" y="65" width="60" height="35" rx="4" fill="#ffffff" stroke="#1e3a8a" stroke-width="2"/>
                        <rect x="35" y="70" width="50" height="3" rx="1" fill="#1e3a8a"/>
                        <rect x="35" y="77" width="50" height="3" rx="1" fill="#1e3a8a"/>
                        <rect x="35" y="84" width="35" height="3" rx="1" fill="#1e3a8a"/>
                        <rect x="35" y="91" width="45" height="3" rx="1" fill="#1e3a8a"/>
                        <path d="M45 62 L60 57 L75 62 L75 67 L60 72 L45 67 Z" fill="#1e3a8a"/>
                        <rect x="74" y="62" width="2" height="8" fill="#1e3a8a"/>
                        <circle cx="76" cy="70" r="2" fill="#f59e0b"/>
                        <defs>
                            <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#3b82f6" />
                                <stop offset="100%" style="stop-color:#1e40af" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                
                <div class="header">
                    Ministerio Educativo de Profesionales Cristianos
                    <br>MEPROC
                </div>
                
                <div class="title">CERTIFICADO DE FINALIZACIÓN</div>
                
                <div class="main-text">
                    Certificamos que
                </div>
                
                <div class="student-name">${studentName}</div>
                
                <div class="main-text">
                    ha completado exitosamente el
                </div>
                
                <div class="course-name">
                    CURSO VIRTUAL Y PRÁCTICO DE REPARACIÓN DE CELULARES
                </div>
                
                <div class="year">2025</div>
                
                <div class="congratulations">
                    Felicitaciones por su dedicación y compromiso en el aprendizaje
                </div>
                
                <div class="date">
                    Otorgado el ${new Date(completionDate).toLocaleDateString('es-ES', {
                        year: 'numeric',
                        month: 'long', 
                        day: 'numeric'
                    })}
                </div>
                
                <div class="signatures">
                    <div class="signature">
                        <div class="signature-line"></div>
                        <div class="signature-title">DIRECTOR</div>
                    </div>
                    <div class="signature">
                        <div class="signature-line"></div>
                        <div class="signature-title">SECRETARIO</div>
                    </div>
                </div>
            </div>
        </body>
        </html>`;

        // Save certificate to database
        const insertResponse = await fetch(`${supabaseUrl}/rest/v1/student_certificates`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                user_id: userId,
                certificate_number: certificateNumber,
                student_name: studentName,
                completion_date: completionDate,
                pdf_generated: true,
                is_valid: true
            })
        });

        if (!insertResponse.ok) {
            const errorText = await insertResponse.text();
            console.error('Failed to save certificate:', errorText);
        }

        return new Response(JSON.stringify({
            data: {
                certificateHTML,
                certificateNumber,
                completionDate,
                message: 'Certificate generated successfully'
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Certificate generation error:', error);

        const errorResponse = {
            error: {
                code: 'CERTIFICATE_GENERATION_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});